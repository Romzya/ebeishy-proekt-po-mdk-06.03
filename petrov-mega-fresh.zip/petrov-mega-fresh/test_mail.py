from app import app, mail, send_email_safe
from flask_mail import Message

with app.app_context():
    print("Тестируем отправку...")
    # Укажите email, на который хотите получить тестовое письмо
    test_recipient = "roman.smartmail.petrov@mail.ru" 
    
    subject = "Тест SMTP из Мир Игрушек"
    body = "Ура! Почта настроена и работает корректно."
    
    # Используем нашу функцию safe
    success = send_email_safe(subject, [test_recipient], body)
    
    if success:
        print("✅ Письмо успешно отправлено! Проверьте ящик (и папку Спам).")
    else:
        print("❌ Ошибка отправки. Смотрите логи выше (или в консоли).")